WordPress 4.2.2 Ready

WordPress 3+ Custom Menu Support

Responsive design

Blog post layout changing – for each page you can choose between:

    Right Sidebar

    Left Sidebar

    Full-width

Easy logo replacement

Sociable Icons section in header

2 single post gallery variants

jQuery tabs, jQuery accordion, sliders, etc

SEO Ready

Favicon and footer logo uploader

Flexslider

Advanced user account page

Post-formats

Typography

Shortcodes

    Sliders

    Columns

    And many more

Custom post-types (News and Reviews)

    Customizable reviews criterias

Audioplayer included

10+ Custom Widgets

3 homepage sliders

Easy inserting sliders to pages and posts

Easy video including from Youtube and Vimeo   

Social icons section on author’s page & social sharing in posts

Contact form validator

Comments with reply functionality (multiple levels depth)

Works and looks similar in all major browsers: Internet Explorer, Firefox, Opera, Safari, Google Chrome

PSD Files included

Documentation included