<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package shift_cv
 */

get_template_part('template', 'blog');
?>