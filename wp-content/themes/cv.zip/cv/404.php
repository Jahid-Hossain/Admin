<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package shift_cv
 */
get_template_part('template', 'blog');
?>